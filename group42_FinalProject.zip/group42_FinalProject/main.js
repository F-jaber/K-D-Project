angular.module('KRRclass', ['chart.js']).controller('MainCtrl', ['$scope', '$http', mainCtrl]);



function elementFactory(tag, text) {
	const el = document.createElement(tag);
	el.textContent = text;
	return el;
}

function mainCtrl($scope, $http) {
	$scope.mySparqlEndpointGlobal = "http://192.168.1.253:7200/repositories/your-endpoint-here"; //copy and paste your repository URL here

	$scope.options_weight = {
		scales: {
			yAxes: [{
				scaleLabel: {
					display: true,
					labelString: 'Weight in lb'
				},
				ticks: {
					min: 0,
					max: 300,
					stepSize: 50,

				}
			}],
			xAxes: [{
				scaleLabel: {
					display: true,
					labelString: 'Fighter'
				}
			}]
		}
	};

	$scope.options_height = {
		scales: {
			yAxes: [{
				scaleLabel: {
					display: true,
					labelString: 'Height in feet'
				},
				ticks: {
					min: 0,
					max: 125,
					stepSize: 25,

				}
			}],
			xAxes: [{
				scaleLabel: {
					display: true,
					labelString: 'Fighter'
				}
			}]
		}
	};


	// beginning of event by date query1
	$scope.startMyAwesomeApp = function () {

		var eventMonth = document.getElementById('eventMonth').value + "-";
		var eventMonthFormat = Number(document.getElementById('eventMonth').value) + "/"

		console.log(eventMonth)
		console.log(eventMonthFormat)

		var query = `PREFIX fig: <http://example/base/fighters/>
		PREFIX ufc: <http://www.semanticweb.org/fakhr/Ultimate_Fighting_Championship/>

		PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
		select ?event ?date ?venue (GROUP_CONCAT(distinct ?match; SEPARATOR = ";") AS ?matches) (GROUP_CONCAT(distinct ?fighter;separator="; ") as ?fighters) where {
			?event a ufc:Event .
			?event ufc:has_Match ?match ;
					 ufc:has_Date ?date ;
					 ufc:has_Venue ?venue.
			?event ufc:includes_Fighter  ?fighter .

		# order by the months
		  FILTER (STRSTARTS(?date, "${eventMonthFormat}") || STRSTARTS(?date, "${eventMonth}"))



		}group by ?event ?venue ?date
`

		$scope.myDisplayMessage = "Information about events for selected date";
		$scope.mySparqlEndpoint = $scope.mySparqlEndpointGlobal;
		$scope.mySparqlQuery = encodeURI(query).replace(/#/g, '%23');


		$http({
			method: "GET",
			url: $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers: { 'Accept': 'application/sparql-results+json', 'Content-Type': 'application/sparql-results+json' }
		})



			.success(function (data, status) {
				var node = document.getElementById("event_by_date_div");
				node.querySelectorAll('*').forEach(n => {
					return n.remove();
				});

				$scope.myData = [];
				$scope.myData.push(["Date", "Venue", "Event", "Matches"]);

				angular.forEach(data.results.bindings, function (val) {
					var match = val.matches.value.split(";")
					match.forEach((element, index) => {
						temp = element.split("/");
						match[index] = temp[temp.length - 1].replace(/_/g, " ");
					});


					var venue = val.event.value.split("/")
					var even = val.venue.value.split("/")
					$scope.myData.push([val.date.value, even[5].replace(/_/g, " "), venue[5].replace(/_/g, " "), match]);
				});

				if ($scope.myData.length <= 1) {
					document.getElementById("event_by_date_div").appendChild(elementFactory("h2", "No data under this name"));
				} else {
					// this code below has an input of arrays and places it into a table.
					var tableArr = $scope.myData

					let table = document.createElement('table');
					table.setAttribute('class', 'style_table');
					for (c = 0; c < tableArr.length; c++) {
						table.insertRow();
						for (i = 0; i < tableArr[c].length; i++) {
							let newCell = table.rows[table.rows.length - 1].insertCell();
							if (i == 2 && c != 0) {
								link = "https://www.ufc.com/event/" + tableArr[c][i].split("-")[0].slice(0, -1).replaceAll(" ", "-").toLowerCase();
								console.log(link)

								var a = document.createElement('a');
								var linkText = document.createTextNode(tableArr[c][i]);
								a.appendChild(linkText);
								a.title = tableArr[c][i];
								a.href = link;
								document.getElementById("eventinfo_div").appendChild(a);
								newCell.appendChild(a);
							} else {
								newCell.textContent = tableArr[c][i];
							}


						}

					}
					document.getElementById("event_by_date_div").appendChild(table);


				}



			})
			.error(function (error) {
				console.log('Error running the input query!' + error);
			});

	};
	// end of event by date query1

	// beginning of event by fighter query2 info
	$scope.JS_for_eventinfo_query2 = function () {

		var name = document.getElementById("name").value;
		var concat_name = name.replace(" ", "_");


		var query = `PREFIX fig: <http://example/base/fighters/>
	PREFIX ufc: <http://www.semanticweb.org/fakhr/Ultimate_Fighting_Championship/>

	PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
	select (GROUP_CONCAT(distinct ?fighter;separator="; ") as ?fighters) ?event ?date ?venue (GROUP_CONCAT(distinct ?match; SEPARATOR = ";") AS ?matches)  where {
		?event a ufc:Event .
		#If you wanna filter for name uncomment below and add name where "Finale"
		FILTER regex(str(?fighter) , "${concat_name}", "i") .
		?event ufc:has_Match ?match ;
				 ufc:has_Date ?date ;
				 ufc:has_Venue ?venue.
		?event ufc:includes_Fighter  ?fighter .

	# order by the months
	#  FILTER contains(?date, "-04-")
	#   FILTER (?date <= "2019-11-11"^^xsd:date)


	}group by ?event ?venue ?date
	#[Like above we have to Group the matches and the fighters together given there are multiple values for those attributes. Additionaly the Regex
	# Filter allows us to theoretically filter the events according to user input.]
	#
`

		$scope.myDisplayMessage2 = "Information about the events that the specified fighter participated in:";
		$scope.mySparqlEndpoint = $scope.mySparqlEndpointGlobal;
		$scope.mySparqlQuery = encodeURI(query).replace(/#/g, '%23');



		$http({
			method: "GET",
			url: $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers: { 'Accept': 'application/sparql-results+json', 'Content-Type': 'application/sparql-results+json' }
		})
			.success(function (data, status) {
				var node = document.getElementById("eventinfo_div");
				node.querySelectorAll('*').forEach(n => {
					return n.remove();
				});

				$scope.myData = [];
				$scope.myData.push(["Fighter", "Event", "Date", "Venue", "Matches"]);


				angular.forEach(data.results.bindings, function (val) {
					var match = val.matches.value.split(";")
					match.forEach((element, index) => {
						temp = element.split("/");
						match[index] = temp[temp.length - 1].replace(/_/g, " ");
					});
					for (let element of match) {

					}

					fighters = val.fighters.value.split("/").pop().replace(/_/g, " ")
					venue = val.venue.value.split("/").pop().replace(/_/g, " ");
					even = val.event.value.split("/").pop().replace(/_/g, " ");

					$scope.myData.push([fighters, even, val.date.value, venue, match]);
				});

				if ($scope.myData.length <= 1) {
					document.getElementById("eventinfo_div").appendChild(elementFactory("h2", "No data under this name"));
				} else {
					// this code below has an input of arrays and places it into a table.
					var tableArr = $scope.myData

					let table = document.createElement('table');
					table.setAttribute('class', 'style_table');
					for (c = 0; c < tableArr.length; c++) {
						table.insertRow();
						for (i = 0; i < tableArr[c].length; i++) {
							let newCell = table.rows[table.rows.length - 1].insertCell();
							if (i == 1 && c != 0) {
								link = "https://www.ufc.com/event/" + tableArr[c][i].split("-")[0].slice(0, -1).replaceAll(" ", "-").toLowerCase();
								console.log(link)

								var a = document.createElement('a');
								var linkText = document.createTextNode(tableArr[c][i]);
								a.appendChild(linkText);
								a.title = tableArr[c][i];
								a.href = link;
								document.getElementById("eventinfo_div").appendChild(a);
								newCell.appendChild(a);
							} else {
								newCell.textContent = tableArr[c][i];
							}


						}

					}
					document.getElementById("eventinfo_div").appendChild(table);
				}




			})
			.error(function (error) {
				console.log('Error running the input query!' + error);
			});

	};


	// end of event by fighter query2 section


	//-- beginning of matches by fighter query3 section -->
	$scope.MatchesByFighter_query3 = function () {

		var fighterName = document.getElementById("fighterName").value.replace(" ", "_");

		var query3 = ["PREFIX fig: <http://example/base/fighters/>\n",
			"PREFIX ufc: <http://www.semanticweb.org/fakhr/Ultimate_Fighting_Championship/>\n",
			"Prefix fit: <http://example/base/fights/>\n",

			"select * where {\n",
			"?match a ufc:Fight\n",
			`FILTER regex(str(?match) , "${fighterName}","i")\n`,
			"?match ufc:has_Referee ?referee ;\n",
			"ufc:has_Winner ?winner ;\n",
			"ufc:has_StoppageRound ?stoppageRound ;\n",
			"ufc:has_StoppageTime ?stoppageTime ;\n",
			"ufc:has_WinMethod ?winMethod ;\n",
			"ufc:has_Event ?event\n",
			"FILTER ( isUri (?winner))\n",
			"filter (strstarts(str(?winner), str(fit:)) )",
			"}",
		].join(" ");
		$scope.myDisplayMessage4 = "Matches that the fighter participated in:";
		$scope.mySparqlEndpoint = $scope.mySparqlEndpointGlobal;
		$scope.mySparqlQuery = encodeURI(query3).replace(/#/g, '%23');

		$http({
			method: "GET",
			url: $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers: { 'Accept': 'application/sparql-results+json', 'Content-Type': 'application/sparql-results+json' }
		})
			.success(function (data, status) {
				var node = document.getElementById("MatchesByFighter_query3_div");
				node.querySelectorAll('*').forEach(n => {
					return n.remove();
				});

				$scope.myData2 = [];
				$scope.myData2.push(["Match", "Referee", "Winner", "Stopping Round", "Stopping Time", "Win Method", "Event"]);

				angular.forEach(data.results.bindings, function (val) {
					var match = val.match.value.split("/")
					var referee = val.referee.value.split("/")
					var winner = val.winner.value.split("/")
					var stoppageround = val.stoppageRound.value.split("/")
					var winMethod = val.winMethod.value.split("/")
					var even = val.event.value.split("/")
					$scope.myData2.push([match[5].replace(/_/g, " "), referee[5].replace(/_/g, " "), winner[5].replace(/_/g, " "), stoppageround[5].replace(/_/g, " "), val.stoppageTime.value, winMethod[5], even[5].replace(/_/g, " ")]);
				});

				if ($scope.myData2.length <= 1) {
					document.getElementById("MatchesByFighter_query3_div").appendChild(elementFactory("h2", "No data under this name"));
				} else {
					// this code below has an input of arrays and places it into a table.
					var tableArr = $scope.myData2

					let table = document.createElement('table');
					table.setAttribute('class', 'style_table');
					for (c = 0; c < tableArr.length; c++) {
						table.insertRow();
						for (i = 0; i < tableArr[c].length; i++) {
							let newCell = table.rows[table.rows.length - 1].insertCell();
							if (i == 6 && c != 0) {
								link = "https://www.ufc.com/event/" + tableArr[c][i].split("-")[0].slice(0, -1).replaceAll(" ", "-").toLowerCase();
								console.log(link)

								var a = document.createElement('a');
								var linkText = document.createTextNode(tableArr[c][i]);
								a.appendChild(linkText);
								a.title = tableArr[c][i];
								a.href = link;
								document.getElementById("eventinfo_div").appendChild(a);
								newCell.appendChild(a);
							} else {
								newCell.textContent = tableArr[c][i];
							}


						}

					}
					document.getElementById("MatchesByFighter_query3_div").appendChild(table);
				}



			})
			.error(function (error) {
				console.log('Error running the input query!' + error);
			});

	};
	//-- end of matches by fighter query3 section -->

	//beginning of fighter info query

	$scope.Figher_query = function () {

		var fighterName2 = document.getElementById("fighterName2").value.replace(" ", "_");

		var query3 = `PREFIX fig: <http://example/base/fighters/>
		PREFIX ufc: <http://www.semanticweb.org/fakhr/Ultimate_Fighting_Championship/>
		Prefix fit: <http://example/base/fights/>
		PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
		PREFIX rnk: <http://example/base/rankings/>
					select ?fighter ?weight ?height ?birthDate ?trainer ?manager ?birthCountry ?birthCity (GROUP_CONCAT(distinct ?event; SEPARATOR = ";") AS ?participated_In) (bound (?champion) as ?c) ?nickname ?rank ?weightDivision
					where{
					?fighter a fig:Fighter .
					FILTER(isUri(?fighter))
					Filter (STRSTARTS(STR(?fighter), STR(fig:)))
					FILTER regex(str(?fighter) , "${fighterName2}","i")
					?fighter ufc:has_Weight ?weight ;
					ufc:has_Height ?height .
					   OPTIONAL { ?fighter ufc:has_BirthDate ?birthDate .}
					OPTIONAL { ?fighter ufc:has_BirthCountry ?birthCountry .}
					OPTIONAL { ?fighter ufc:has_BirthCity ?birthCity .}
					OPTIONAL { ?fighter ufc:participated_In ?event.}
					OPTIONAL { ?fighter ufc:has_Nickname ?nickname .}
					OPTIONAL {?fighter ufc:has_Rank ?rank.}
					OPTIONAL {
					?fighter ufc:fightsIn ?weightDivision.
					FILTER(isUri(?weightDivision)).
					FILTER(STRSTARTS(STR(?weightDivision), STR(rnk:))).
					}
					OPTIONAL {?fighter ufc:has_Trainer ?trainer.}
					OPTIONAL {?fighter ufc:has_Manager ?manager.}
					OPTIONAL {?fighter rdf:type ?champion. FILTER(strstarts(str(?champion), str(ufc:Champion))) .}
					}
					GROUP BY ?fighter ?weight ?height ?birthDate ?birthCountry ?birthCity ?nickname ?rank ?weightDivision ?manager  ?trainer ?champion
	`
		$scope.myDisplayMessage3 = "Information about fighter";
		$scope.mySparqlEndpoint = $scope.mySparqlEndpointGlobal;
		$scope.mySparqlQuery = encodeURI(query3).replace(/#/g, '%23');

		$http({
			method: "GET",
			url: $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers: { 'Accept': 'application/sparql-results+json', 'Content-Type': 'application/sparql-results+json' }
		})
			.success(function (data, status) {
				var node = document.getElementById("FighterInfo_query4_div");
				node.querySelectorAll('*').forEach(n => {
					return n.remove();
				});

				$scope.myData2 = [];
				$scope.myData2.push(["Fighter", "Weight (in lb)", "Height (in feet)", "Birthdate", "Country of birth", "City of Birth", "Nickname", "Rank", "Weightdivision", "Manager", "Trainer", "Champion"]);

				angular.forEach(data.results.bindings, function (val) {
					$scope.myData2.push([val.fighter.value.split("/").pop().replace(/_/g, " "), val.weight.value, val.height.value, ((typeof (val.birthDate) == "undefined")) ? 'No data' : val.birthDate.value, val.birthCountry.value.split("/").pop().replace(/_/g, " "), val.birthCity.value.split("/").pop().replace(/_/g, " "), ((typeof (val.nickname) == "undefined")) ? 'No data' : val.nickname.value, ((typeof (val.rank) == "undefined")) ? 'No data' : val.rank.value, ((typeof (val.weightDivision) == "undefined")) ? 'No data' : val.weightDivision.value.split("/").pop(), ((typeof (val.manager) == "undefined")) ? 'No data' : val.manager.value.split("/").pop().replace(/_/g, " "), ((typeof (val.trainer) == "undefined")) ? 'No data' : val.trainer.value.split("/").pop().replace(/_/g, " "), ((typeof (val.c) == "undefined")) ? 'No data' : val.c.value]);
				});


				if ($scope.myData2.length <= 1) {
					document.getElementById("FighterInfo_query4_div").appendChild(elementFactory("h2", "No data under this name"));
				} else {
					// this code below has an input of arrays and places it into a table.
					var tableArr = $scope.myData2

					let table = document.createElement('table');
					table.setAttribute('class', 'style_table');
					for (let row of tableArr) {
						table.insertRow();
						for (let cell of row) {
							let newCell = table.rows[table.rows.length - 1].insertCell();
							newCell.textContent = cell;
						}
					}
					document.getElementById("FighterInfo_query4_div").appendChild(table);
				}



			})
			.error(function (error) {
				console.log('Error running the input query!' + error);
			});

	};

	//end of fighter info query

	//beginng of weight height query
	$scope.get_by_date_query2 = function () {

		var firstname1 = document.getElementById("firstname1").value;
		var lastname1 = document.getElementById("lastname1").value;
		var firstname2 = document.getElementById("firstname2").value;
		var lastname2 = document.getElementById("lastname2").value;
		var concat_name1 = ("fig:" + (firstname1.charAt(0).toUpperCase() + firstname1.slice(1)) + "_" + (lastname1.charAt(0).toUpperCase() + lastname1.slice(1))).replace(" ", "");
		var concat_name2 = ("fig:" + (firstname2.charAt(0).toUpperCase() + firstname2.slice(1)) + "_" + (lastname2.charAt(0).toUpperCase() + lastname2.slice(1))).replace(" ", "");

		var query = `PREFIX fig: <http://example/base/fighters/>
					PREFIX ufc: <http://www.semanticweb.org/fakhr/Ultimate_Fighting_Championship/>

					select  ?weight1 ?height1 ?weight2 ?height2 where {
						${concat_name1} ufc:has_Weight ?weight1 ;
								 ufc:has_Height ?height1 .
						${concat_name2} ufc:has_Weight ?weight2 ;
								 ufc:has_Height ?height2 .
					}
			`

		$scope.myDisplayMessage5 = "A comparision between the weight and height of each fighter:";
		$scope.mySparqlEndpoint = $scope.mySparqlEndpointGlobal;
		$scope.mySparqlQuery = encodeURI(query).replace(/#/g, '%23');


		// };
		$http({
			method: "GET",
			url: $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers: { 'Accept': 'application/sparql-results+json', 'Content-Type': 'application/sparql-results+json' }
		})
			.success(function (data, status) {
				document.getElementById("canvas1").style.display = null
				document.getElementById("canvas2").style.display = null

				$scope.myDynamicLabels = [];
				$scope.myDynamicData = [];

				$scope.myDynamicLabels2 = [];
				$scope.myDynamicData2 = [];


				// now iterate on the results.
				angular.forEach(data.results.bindings, function (val) {
					$scope.myDynamicLabels.push(concat_name1.split(":").pop().replace(/_/g, " ") + " weight");
					$scope.myDynamicLabels2.push(concat_name1.split(":").pop().replace(/_/g, " ") + " height");
					$scope.myDynamicLabels.push(concat_name2.split(":").pop().replace(/_/g, " ") + " weight");

					$scope.myDynamicLabels2.push(concat_name2.split(":").pop().replace(/_/g, " ") + " height");

					$scope.myDynamicData.push((val.weight1.value));
					$scope.myDynamicData2.push((val.height1.value));
					$scope.myDynamicData.push((val.weight2.value));

					$scope.myDynamicData2.push((val.height2.value));





				});



				if ($scope.myDynamicData.length <= 1) {
					document.getElementById("canvas1").style.display = 'none'
					document.getElementById("event_by_date_section2_div").appendChild(elementFactory("h2", "No weight data under the names"));
				}

				if ($scope.myDynamicData2.length <= 1) {
					document.getElementById("canvas2").style.display = 'none'
					document.getElementById("event_by_date_section2_div").appendChild(elementFactory("h2", "No height data under the names"));
				}
			})
			.error(function (error) {
				console.log('Error running the input query!' + error);
			});


	}
	//end of weight height query

	//<!-- beginning of DBpedia founders query6 section -->
	$scope.startDBquery = function () {

		var query6 = `PREFIX ufc: <http://www.semanticweb.org/fakhr/Ultimate_Fighting_Championship/>
									PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

									select ?founders where{
    							?founders rdf:type ufc:Founder
									}
										`
		$scope.mySparqlEndpoint = $scope.mySparqlEndpointGlobal;
		$scope.mySparqlQuery = encodeURI(query6).replace(/#/g, '%23');

		$http({
			method: "GET",
			url: $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers: { 'Accept': 'application/sparql-results+json', 'Content-Type': 'application/sparql-results+json' }
		})
			.success(function (data, status) {

				$scope.myData2 = [];
				$scope.myData2.push([]);

				angular.forEach(data.results.bindings, function (val) {

					$scope.myData2.push([val.founders.value.split("/").pop().replace(/_/g, " ")]);
				});



				if ($scope.myData2.length <= 1) {
					document.getElementById("Founders_query6_div").appendChild(elementFactory("h2", "No data under this name"));
				} else {
					// this code below has an input of arrays and places it into a table.
					var tableArr = $scope.myData2


					let table = document.createElement('table');
					table.setAttribute('id', 'founder');
					for (c = 0; c < tableArr.length; c++) {
						table.insertRow();
						for (i = 0; i < tableArr[c].length; i++) {
							let newCell = table.rows[table.rows.length - 1].insertCell();
							if (i == 0 && c != 0) {
								link = "https://en.wikipedia.org/wiki/" + tableArr[c][i].split("-")[0].replaceAll(" ", "_");
								console.log(link)

								var a = document.createElement('a');
								var linkText = document.createTextNode(tableArr[c][i]);
								a.appendChild(linkText);
								a.title = tableArr[c][i];
								a.href = link;
								document.getElementById("eventinfo_div").appendChild(a);
								newCell.appendChild(a);
							} else {
								newCell.textContent = tableArr[c][i];
							}


						}

					}
					document.getElementById("Founders_query6_div").appendChild(table);
				}



			})
			.error(function (error) {
				console.log('Error running the input query!' + error);
			});
		//<!-- end of query6 section -->
	}

	$scope.JS_for_fights_won_query = function () {
		var concat_name_won = document.getElementById("name_fights_won").value.replace(" ", "_");




		var query = `PREFIX fig: <http://example/base/fighters/>
		PREFIX ufc: <http://www.semanticweb.org/fakhr/Ultimate_Fighting_Championship/>
		PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
		select ?fighter ?numberGamesWon where {
			?fighter a fig:Fighter.
			OPTIONAL{ ?fighter ufc:has_GamesWon ?numberGamesWon. }
			FILTER(isUri(?fighter)).
			FILTER(STRSTARTS(STR(?fighter), STR(fig:))).
			FILTER regex(str(?fighter) , "${concat_name_won}", "i") .
		}
`

		$scope.myDisplayMessage7 = "The number of fights won by the fighter:";
		$scope.mySparqlEndpoint = $scope.mySparqlEndpointGlobal;
		$scope.mySparqlQuery = encodeURI(query).replace(/#/g, '%23');




		$http({
			method: "GET",
			url: $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers: { 'Accept': 'application/sparql-results+json', 'Content-Type': 'application/sparql-results+json' }
		})
			.success(function (data, status) {
				var node = document.getElementById("fights_won_info_div");
				node.querySelectorAll('*').forEach(n => {
					return n.remove();
				});

				$scope.myData = [];
				$scope.myData.push(["Fighter", "Number of Fights won"]);



				angular.forEach(data.results.bindings, function (val) {
					$scope.myData.push([val.fighter.value.split("/").pop().replace(/_/g, " "), ((typeof (val.numberGamesWon) == "undefined")) ? '0' : val.numberGamesWon.value]);
				});

				if ($scope.myData.length <= 1) {
					document.getElementById("fights_won_info_div").appendChild(elementFactory("h2", "No data under this name"));
				} else {
					// this code below has an input of arrays and places it into a table.
					var tableArr = $scope.myData

					let table = document.createElement('table');
					table.setAttribute('class', 'style_table');
					for (let row of tableArr) {
						table.insertRow();
						for (let cell of row) {
							let newCell = table.rows[table.rows.length - 1].insertCell();
							newCell.textContent = cell;
						}
					}
					document.getElementById("fights_won_info_div").appendChild(table);
				}



			})
			.error(function (error) {
				console.log('Error running the input query!' + error);
			});




	};
}
