Thanks for downloading this application!

To use the application, please import the Ontology.ttl file into graphDB and change the global sparql endpoint in the main.js file to
the endpoint of your graphDB repository. Finally just open the index.html file and enjoy!
- Group 42, K&D 2020


